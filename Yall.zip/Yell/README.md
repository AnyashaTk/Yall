# Yell
 The application reads the parameters of the device's position in space and determines how fast it is moving. If the device moves too fast, the app emits a loud sound, notifying everyone around that it is “unhappy”.
